This is my hello world GFX demo inspired by some old Adafruit code.

It is present in some form in these trees:
* https://github.com/marcmerlin/LED-Matrix/blob/master/examples/directmatrix8x8_tricolor_direct_sr/directmatrix8x8_tricolor_direct_sr.ino
* https://github.com/adafruit/Adafruit_NeoMatrix/tree/master/examples/MatrixGFXDemo
* https://github.com/adafruit/RGB-matrix-Panel/blob/master/examples/PanelGFXDemo_16x32/PanelGFXDemo_16x32.ino-
* https://github.com/marcmerlin/FastLED_NeoMatrix/tree/master/examples/MatrixGFXDemo
* https://github.com/mrfaptastic/ESP32-RGB64x32MatrixPanel-I2S-DMA/blob/master/examples/PanelGFXDemo/PanelGFXDemo.ino
* https://github.com/marcmerlin/SmartMatrix_GFX/tree/master/examples/MatrixGFXDemo
